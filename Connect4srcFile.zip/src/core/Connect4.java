/** 
 * This is a game of Connect4 with computer player 2 option
 * @author Nathanial Bergan
 * @date 29-Oct-2018
 * @version 2.0 
 **/

package core;

import java.util.Scanner;

/** Class Description: This is the source code for the Connect4 game */
public class Connect4 {
	public Integer [][] board = new Integer[6][7];
	int turn = 1;
	int counter = 0;
	Integer result = null;
	int columnPick = 0;
	public boolean computerPlayer = false;
	
	Connect4ComputerPlayer computer = new Connect4ComputerPlayer();
	Scanner in = new Scanner(System.in);
	
	/** Constructor Description: This is constructor for the Connect4 game
	 *  It sets up the board with 9's in each slot
	 *  Then checks if player 2 is human or computer
	 *  Then it starts the game and each player takes a turn  */
	public Connect4() {
		setBoardUp();
		checkPlayerOrComputer();
		startGame();
	}
	
	/** setBoardUp(): Sets up the board with 9's */
	public void setBoardUp(){
		for(int i = 0; i < 6; i++)
		{
			for(int j = 0; j < 7; j++)
			{
				board[i][j] = 9;
			}
		}
	}
	
	/** checkPlayerOrComputer(): Sets boolean if human or computer will be playing as player 2
	 * @throws Exception if 'P' or 'C' is not selected, but user can try again */
	public void checkPlayerOrComputer() {
		int flag = 1;
		
		// Print beginning message
		System.out.println(" -- CONNECT 4 --");
		System.out.println("Please make a selection:");
		System.out.println("P - Human player 2");
		System.out.println("C - Computer player 2");
		
		// Get user input
		while(flag == 1) {

			
			char humanOrComputer = in.next().charAt(0);
			
			// The 
			try {
				if(humanOrComputer == 'C' || humanOrComputer == 'P')
				{
					flag = 0;
					if(humanOrComputer == 'C')
					{
						computerPlayer = true;
						System.out.println("Game against computer.");
					}
					else
						System.out.println("Two player human game");
					
				}
				else
					throw new Exception();
			}
			catch(Exception ex) {
				System.out.println("Please enter a character. Either 'C' or 'P'");
				continue;
			}
		}

	}
	
	/** startGame(): Starts the game and loops until one player wins 
	 * @throws Exception if selection is out of bounds, but user can try again*/
	public void startGame() {
		
		System.out.println("BEGIN THE GAME \n");
		while(result == null) {
			display_board();					// Display board
			System.out.println();
			display_message();					// Display message to player 1
			
			// See if computer needs to make a move
			if(computerPlayer && turn == 0) // Computer's turn
			{
				columnPick = computer.generate_move(); // Generates an int from 0 - 6 assigns to columnPick
				System.out.println("Computer picks: " + (columnPick + 1));
			}
			else // Human turn
			{
				while(true) {
					try {
						columnPick = in.nextInt() - 1;		// Wait for input
						if(columnPick < 0 || columnPick > 6) 	// input is out of bounds
						{
							throw new Exception("ERROR - # out of bounds. Please try again.");
						}
						break;
					}
					catch (Exception ex) {
						System.out.println(ex);
					}
					
				}
			}

			if(!place_token(columnPick))	// If column full - reset turn
				continue;
			counter++;
			if(check_4_in_a_row())
			{
				if(turn == 1) {
					result = 1;
					break;
				}
				else {
					if(computerPlayer)
						result = 3;
					else {
						result = 2;
						break;
					}
				}

			}
			if(check_full())
			{
				result = 0;
				break;
			}
			change_turn();
		}
		display_result();
	}
	
	/** check_4_in_a_row(): Scans board vertical, horizontal, and diagonal for a win
	 * @return returns true if 4 in a row is found  */
	public boolean check_4_in_a_row() {
		int count = 0;
		
		// Check Vertical_____________________
		count = 0;  // reset count
		for(int j = 0; j < 7; j++)
		{
			for(int i = 0; i < 6; i++)
			{
				if(board[i][j] == turn)
				{
					count++;
					if(count == 4)
						return true;
				}
				else
					count = 0;
			}
		}
		
		// Check Horizontal_____________________
		count = 0;  // reset count
		for(int i = 0; i < 6; i++)
		{
			for(int j = 0; j < 7; j++)
			{
				if(board[i][j] == turn)
				{
					count++;
					if(count == 4)
						return true;
				}
				else
					count = 0;
			}
		}
		
		// Check Diagonal_____________________
		int rowMax = 6;
		int columnMax = 7;
		int row = 0;
		int column = 0;
		count = 0;   // reset count
		
		// Scan Rows Diagonally UP //
		for(int i = 0; i < rowMax; i++) { 
			row = i; // This moves scanner down a row
			
			//Scan and STOP
			while(row >= 0) {
				// Check
				if(board[row][column] == turn)
				{
					count++;
					if(count == 4)
						return true;
				}
				if(row == 0)
					break;
				
				row--;
				column++;
			}
			count = 0;	
			column = 0;
		}
				
		// Scan Columns Diagonally UP //
		for(int j = 1; j < columnMax; j++) { 
			column = j; // This moves scanner down a row
			row = 5;
			
			//Scan and STOP
			while(column < columnMax) {
				// Check
				if(board[row][column] == turn)
				{
					count++;
					if(count == 4)
						return true;
				}
				if(column == columnMax)
					break;
				
				row--;
				column++;
			}
			count = 0;	
		}
		
		// Scan Rows Diagonally DOWN \\
		column = 0;
		for(int i = 5; i >= 0; i--) { 
			row = i; // This moves scanner up a row
			
			//Scan and STOP
			while(row < rowMax) {
				// Check
				if(board[row][column] == turn)
				{
					count++;
					if(count == 4)
						return true;
				}
				if(row == 5)
					break;
				
				row++;
				column++;
			}
			count = 0;	
			column = 0;
		}
		
		// Scan Columns Diagonally DOWN \\
		row = 0;
		column = 1;
		for(int j = 1; j < columnMax; j++) { 
			column = j; // This moves scanner down a row
			
			//Scan and STOP
			while(column < columnMax) {
				// Check
				if(board[row][column] == turn)
				{
					count++;
					if(count == 4)
						return true;
				}
				if(column == columnMax)
					break;
				
				row++;
				column++;
			}
			count = 0;	
			row = 0;
		}
		
		return false;	
	}
	
	/** check_full(): Checks if 42 tokens have been placed
	 * @return returns true if board is full  */
	public boolean check_full() {
		if(counter == 42)
			return true;
		else
			return false;
	}
	
	/** change_turn(): Switches player turn from 1 to 0
	 * 1 - Player 1 (X)
	 * 0 - Player 2 (O)*/
	public void change_turn() {
		if(turn == 1)
			turn = 0;
		else
			turn = 1;
	}
	
	/** display_result(): Displays end game result
	 *  0: Draw / 1: Player 1 win / 2: Player 2 win*/
	public void display_result() {
		switch(result)
		{
		case 0: 
			display_board();
			System.out.println("DRAW!");
			break;
		case 1:
			display_board();
			System.out.println("PLAYER 1 WINS!");
			break;
		case 2:
			display_board();
			System.out.println("PLAYER 2 WINS!");
			break;
		case 3:
			display_board();
			System.out.println("COMPUTER WINS!");
			break;
		}
	}
	
	/** display_board(): Displays game board */
	public void display_board() {
		for(int i = 0; i < 6; i++)
		{
			for(int j = 0; j < 7; j++)
			{
				System.out.print("|" + check_X_O(board[i][j]));
			}
			System.out.println("|");
		}
	}
	
	/** check_X_O(): Converts numbers to X or O
	 *  @param pass in an integer - 9: " " / 1: X / 0: O 
	 *  @return a String - 9: " " / 1: X / 0: O */
	
	public String check_X_O(Integer i) {
		switch(i) {
		case 0:
			return "O";
		case 1:
			return "X";
		default:
			return " ";
		}
	}
	
	/** place_token(): Place a token in bottom most zone
	 * @param pass in an int for column selected
	 * @return return true if token placed */
	public boolean place_token(int pick) {
		Integer slot = 0;
		boolean empty = true;
		int count = 0;
		
		if(board[slot][pick] != 9) {		// Check if column is full
			System.out.println("Row is full! Try again!");
			return false;
		}
		else {
			while(empty && count < 6)
			{
				if(board[slot][pick] == 9)
				{
					slot++;
					count++;
				}				
				else
					empty = false;
			}
			board[slot-1][pick] = turn;
			return true;
		}	
	}
	
	/** display_message(): Display message to Player 1 and 2 */
	public void display_message() {
		if(turn == 1)
			System.out.println("PlayerX - your turn. Choose a column number from 1-7.");
		else
			System.out.println("PlayerO - your turn. Choose a column number from 1-7.");
	}
}
