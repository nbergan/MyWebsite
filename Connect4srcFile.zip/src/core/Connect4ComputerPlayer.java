/** 
 * This is the computer logic for a coomputer player in Connect4
 * @author Nathanial Bergan
 * @date 29-Oct-2018
 * @version 1.0 
 **/

package core;
import java.util.Random;

/** Class Description: This is the source code for the computer player logic in a Connect4 game */
public class Connect4ComputerPlayer {
	
	// Creates and instance of the Random class
	Random rand = new Random();
	
	// No constructor needed
	
	/** generate_move(): Randomly generates a number between 0 - 6 to place computer token */
	int generate_move(){
		int random_move = rand.nextInt(7);
		return random_move;
	}
}
