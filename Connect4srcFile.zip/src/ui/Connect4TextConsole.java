package ui;
import core.Connect4;

/** 
 * This is a game of Connect4
 * @author Nathanial Bergan
 * @version 1.0  23-Oct-2018
 **/

public class Connect4TextConsole {
	public static void main(String[] args) {
		Connect4 game = new Connect4();
	}
}

